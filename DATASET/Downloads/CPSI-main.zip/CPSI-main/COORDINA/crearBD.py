from modelos import modelo
# Connect to the database

# Create tables

db.create_tables([COORDINACION, AREA, TITULACION, FICHA, NCL, RAP, ACTIVIDAD, RAP_ACTIVIDAD, FICHAS_ACTIVIDAD])
