# CENTRO DE PRODUCCION DE SOLUCIONES INTELIGENTES
<link href="http://siomi.datasena.com/analitica/Estilo.css" rel="stylesheet" type="text/css" />

<img src="https://blogger.googleusercontent.com/img/a/AVvXsEimdqxynaYJeDRuTUp3lzEWFnnQSC2KTVSxvnV70I2eZ5tOCfjwdNnExSTSm2tCf1xBFHVHwsN80OCpDCO0J80UTNWxPC86s7s5aB8rnizg7guNowqTxhr5Fd9WH48n7pn8uLZNFTgXuSGUH6BNncmfQEpOz9pAe_T0zD8n2-aGZk8-C_l6GWk-aq60fQ=s960">
<br>
<a href="https://github.com/fegasu/CPSI?tab=readme-ov-file">Regresar</a><br>
Pasos a seguir para la practica CONSUMIR SERVICIOS APIRESTS:
<ul>
<li>Descargue el <a href="https://github.com/fegasu/CPSI/archive/refs/heads/main.zip">archivo</a> desde este github</li>
<li>Descomprima el archivo descargado</li>
<li>Asegurese que python este instalado, de lo contrario descrguelo <a href="https://www.python.org/downloads/">Aqui</a></li>
<li>Instale el ambiente virtual:<a href="#"> <mark>pip install virtualenv</mark></a></li>
<li>Crear el ambiente virtual: <a href="#"><mark>python -m venv env</mark></a></li>
<li>Inicie el ambiente virtual con el archivo <a href="#">inicio.bat</a></li>
<li>Instale los requerimientos necesarios <a href="#">requeri.bat</a> &oacute; escriba el comando: <a href="">pip install -r requirements.txt</a></li>

<li>Inicie el servidor web y la API con el archivo <a href="#">multi.bat</a> desde el ambiente virtual</li>
<li>Ingrese al navegador y escriba la url http://127.0.0.1:8000
</ul>

 
