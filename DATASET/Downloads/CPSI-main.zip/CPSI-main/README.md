# CENTRO DE PRODUCCION DE SOLUCIONES INTELIGENTES
<link href="http://siomi.datasena.com/analitica/Estilo.css" rel="stylesheet" type="text/css" />

<img src="https://blogger.googleusercontent.com/img/a/AVvXsEimdqxynaYJeDRuTUp3lzEWFnnQSC2KTVSxvnV70I2eZ5tOCfjwdNnExSTSm2tCf1xBFHVHwsN80OCpDCO0J80UTNWxPC86s7s5aB8rnizg7guNowqTxhr5Fd9WH48n7pn8uLZNFTgXuSGUH6BNncmfQEpOz9pAe_T0zD8n2-aGZk8-C_l6GWk-aq60fQ=s960">
<br>
<ul>
<li>
<a href="https://github.com/fegasu/CPSI/blob/main/APIREST.md">CONSUMIR SERVICIOS APIRESTS</a></li>
<li><a href="https://docs.google.com/presentation/d/e/2PACX-1vSTzLSx6Wo2IrYrcESQlpIe0vFapdvG0cGtbQF4he1RptdsjKZWBMAjplsGresQsw/pub?start=false&loop=false&delayms=3000">PRESENTACION BLUEPRINT</a></li>
<li><a href="https://ecampuzano.notion.site/Crear-una-API-Flask-con-Blueprints-y-MongoDB-ab1c48df22734de6928c6a7e01914de2">EJEMPLO BLUEPRINT</a></li>

<li><a href="https://docs.google.com/presentation/d/e/2PACX-1vTc_6H2AzaWIW1Hh5M3a5u8uYf_AvnHKsRf7LNTR7kpLC5KB1pg6al53u4Kdt3MSw/pub?start=false&loop=false&delayms=3000">CAPA DE PERSISTENCIA</a></li>
<li><a href="https://github.com/fegasu/CPSI/tree/main/NOVEDADES#readme">PROYECTO NOVEDADES AMBIENTE DE FORMACION</a></li>

</ul>
 
